import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = xbmcaddon . Addon ( id = 'plugin.video.phantomwizard' )
if 78 - 78: i11i . oOooOoO0Oo0O
def iI1 ( url ) :
 i1I11i = urllib2 . Request ( url )
 i1I11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 OoOoOO00 = urllib2 . urlopen ( i1I11i )
 I11i = OoOoOO00 . read ( )
 OoOoOO00 . close ( )
 return I11i
 if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
 if 8 - 8: Oo / iII11iiIII111 % iiiIIii1I1Ii . O00oOoOoO0o0O
 if 43 - 43: Oo0 * OO - oooO0oo0oOOOO - ooO0oo0oO0 - i111I * OoooooooOO
 if 84 - 84: i111I - i11iIiiIii - i11i % ooO0oo0oO0 - iIii1I11I1II1
def iiI1iIiI ( ) :
 I11i = iI1 ( 'http://phantomxbmc.googlecode.com/svn/Xpert/tools/wizard.txt' )
 OOo = xbmc . getInfoLabel ( "System.ProfileName" )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 Oooo0000 = xbmcgui . Dialog ( )
 if Oooo0000 . yesno ( "IM PHANTOM" , "WELCOME TO PHANTOM QUICK WIZARD SET UP DO YOU" , "WANT TO INSTALL ALL PLUGIN GOODIES QUICKLY" ) :
  i11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  I11 = xbmcgui . DialogProgress ( )
  I11 . create ( "Phantom Wizard" , "Downloading " , '' , 'Please Wait' )
  Oo0o0000o0o0 = os . path . join ( i11 , 'XBMC.zip' )
  oOo0oooo00o = os . path . join ( i11 , 'splash.zip' )
  try :
   os . remove ( Oo0o0000o0o0 )
  except :
   pass
  downloader . download ( 'http://download1327.mediafire.com/ddejnx3vefsg/gc9edresdf47d7p/XBMC.zip' , Oo0o0000o0o0 , I11 )
  oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  I11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  print '======================================='
  print oO0o0o0ooO0oO
  print '======================================='
  extract . all ( Oo0o0000o0o0 , oO0o0o0ooO0oO , I11 )
  if xbmc . getCondVisibility ( 'system.platform.linux' ) :
   if Oooo0000 . yesno ( "PHANTOM" , "I NOTICE YOU HAVE A LINUX BUILD" , "CLICK YES IF YOU ARE A MEDIA BOX" , "CLICK NO IF YOU ARE A NORMAL LINUX PC/LAPTOP" ) :
    oo0o0O00 = os . path . join ( i11 , 'skintegrate_linux.zip' )
    downloader . download ( 'http://sproutone.com/skintegrate_linux.zip' , oo0o0O00 , I11 )
    extract . all ( oo0o0O00 , oO0o0o0ooO0oO , I11 )
  I11 . update ( 0 , "" , "Downloading" )
  downloader . download ( 'http://sproutone.com/splash.zip' , oOo0oooo00o , I11 )
  I11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( oOo0oooo00o , Ii1IIii11 , I11 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  oO = re . compile ( 'plugin="(.+?)"' ) . findall ( I11i )
  for i1iiIIiiI111 in oO :
   xbmc . executebuiltin ( "Skin.SetString(%s)" % i1iiIIiiI111 )
  time . sleep ( 2 )
  xbmc . executebuiltin ( 'ReloadSkin()' )
  xbmc . executebuiltin ( "LoadProfile(%s)" % OOo )
  if 62 - 62: i11iIiiIii - i11i
  if 43 - 43: ii1IiI1i - i1IIi + ooO0oo0oO0 + Oo0
def iI1 ( url ) :
 i1I11i = urllib2 . Request ( url )
 i1I11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 OoOoOO00 = urllib2 . urlopen ( i1I11i )
 I11i = OoOoOO00 . read ( )
 OoOoOO00 . close ( )
 return I11i
 if 17 - 17: IIIiiIIii
iiI1iIiI ( )
if 64 - 64: Oo0 % i1IIi % OoooooooOO
if 3 - 3: OO + O0
if 42 - 42: iiiIIii1I1Ii / i1IIi + i11iIiiIii - Oo0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 78 - 78: i1
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
