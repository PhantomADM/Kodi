import xbmc
import xbmcaddon
import os
import shutil

def onerror(func, path, exc_info):
    import stat
    if not os.access(path, os.W_OK):
        # Is the error an access error ?
        os.chmod(path, stat.S_IWUSR)
        func(path)
    else:
        raise

def cleann():
    xbmc.log("------------------------------------------------------------------------")
    addonPath = xbmc.translatePath( xbmcaddon.Addon(id = 'plugin.video.hubwizard').getAddonInfo('path') )
    dataPath = xbmc.translatePath( xbmcaddon.Addon(id = 'plugin.video.hubwizard').getAddonInfo('Profile') )
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)

    donefile = os.path.join(dataPath,"done.txt")
    if os.path.exists(donefile):
        xbmc.log(" Done")
        return

    f = open(donefile,"w")
    f.write("done")
    f.flush()
    f.close()

    addons_path = os.path.abspath(os.path.join(addonPath,".."))
    xbmc.log(" Cleaning "+addons_path)
    xbmc.log("------------------------------------------------------------------------")

    listing = []
    listing.append("plugin.audio.xbmchubmusic")
    listing.append("plugin.video.EasyNews")
    listing.append("plugin.video.MikeysKaraoke")
    listing.append("plugin.video.disneyjunior")
    listing.append("plugin.video.expattv")
    listing.append("plugin.video.filmon")
    listing.append("plugin.video.footballreplays")
    listing.append("plugin.video.itv")
    listing.append("plugin.video.kickoff")
    listing.append("plugin.video.muchmovies")
    listing.append("plugin.video.mydropbox")
    listing.append("plugin.video.notfilmon")
    listing.append("plugin.video.ntv")
    listing.append("plugin.video.offside")
    listing.append("plugin.video.simplymovies")
    listing.append("plugin.video.ytEpisodes")
    listing.append("plugin.video.AWEsomeDL")
    listing.append("plugin.video.OCM")
    listing.append("plugin.video.movie105")
    listing.append("plugin.video.moviekingdom")
    listing.append("plugin.video.tubeplus")
    listing.append("plugin.video.tv-release")
    listing.append("plugin.video.movie25")
    listing.append("plugin.video.bmovies")
    listing.append("plugin.video.cartoonworld")
    listing.append("plugin.video.dovat")
    listing.append("plugin.video.favorites")
    listing.append("plugin.video.funandmovies")
    listing.append("plugin.video.iwatchonline")
    listing.append("plugin.video.skyaccess.se")
    listing.append("plugin.video.tellynagari")
    listing.append("plugin.video.the666sicco")
    listing.append("plugin.video.watchhistory")
    listing.append("plugin.video.watchwrestling")
    listing.append("plugin.video.wweonline")
    listing.append("plugin.video.zmovies")
    listing.append("plugin.video.Movie2k")
    listing.append("plugin.video.sportsaholic")
    listing.append("repository.mikey1234-repo")
    listing.append("repository.Mikey1234_private")
    listing.append("repository.Jas0npc")
    listing.append("repository.voinage")
    listing.append("repository.the-one")
    listing.append("repository.mash2k3")
    listing.append("mashup-repository.mash2k3")
    listing.append("plugin.video.hubmaintenance")

    for entry in listing:
        fulldir = os.path.join( addons_path , entry )
        if os.path.exists(fulldir):
            xbmc.log(" Found "+entry)
            shutil.rmtree(fulldir, onerror=onerror)

    xbmc.log("------------------------------------------------------------------------")

    import xbmcgui
    dialog = xbmcgui.Dialog()
    dialog.ok("XBMCHUB TEAM", "Beware of Imposter XBMC Fraud Sites","XBMCHUB.COM is the Only Real Source")

try:
    cleann()
except:
    import traceback
    xbmc.log(traceback.format_exc())
