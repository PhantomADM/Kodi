import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import extract
import downloader


ADDON = xbmcaddon.Addon(id='plugin.video.phantominstall')
base_url='https://phantomxbmc.googlecode.com/svn/PhantomMod/'
xbmcfolder = xbmc.translatePath(os.path.join('special://home',''))
addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))

def CATEGORIES():
        link=OPEN_URL(base_url+'skins.txt')
        common=re.compile('common="(.+?)"').findall (link)
        match=re.compile('name="(.+?)".+?skins="(.+?)".+?desc="(.+?)"',re.DOTALL).findall (link)
        for name ,zip_url ,description in match:
        
            url_dest    =   base_url+'%s/%s' %(name,zip_url)
            iconimage   =   base_url+'%s/icon.png' %name
            fanart      =   base_url+'%s/fanart.png' %name
            
            addDir(name,url_dest,1,iconimage,fanart,description,common[0])
            
        setView('movies', 'everything') 
       
       
                      												  
def Install(name,url,common):
        profile = xbmc.getInfoLabel("System.ProfileName" )
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        dp = xbmcgui.DialogProgress()
        dp.create("Phantom","Downloading ",name, 'Please Wait')
        lib=os.path.join(path,name+'.zip')
        commonzip=os.path.join(path,common)
        splash=os.path.join(path,'splash.zip')
		installation=os.path.join(path,'Phantom.zip')
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)#download skin
        dp.update(0,name, "Extracting Zip Please Wait")
        extract.all(lib,addonfolder,dp)#extract skin
        
        if os.path.exists(commonzip)==False:
            downloader.download('http://sproutone.com/skins/common.zip', commonzip, dp)#download common
            dp.update(0,name, "Extracting Zip Please Wait")
            extract.all(commonzip,addonfolder,dp)#extract common
        
        dp.update(0,"", "Downloading") #download splash 
        downloader.download('https://phantomxbmc.googlecode.com/svn/PhantomMod/splash.zip', splash, dp)        
        dp.update(0,"", "Extracting Zip Please Wait")
        extract.all(splash,xbmcfolder,dp)#extract splash
		
		if os.path.exists(installation)==False:
            downloader.download('https://phantomxbmc.googlecode.com/svn/PhantomMod/Phantom.zip', installation, dp)#download 
            dp.update(0,name, "Extracting Zip Please Wait")
            extract.all(installation,addonfolder,dp)
        
        xbmc.executebuiltin('UpdateLocalAddons ') 
        xbmc.executebuiltin("UpdateAddonRepos")
        dialog = xbmcgui.Dialog()
        if dialog.yesno("Phantom", "Would You Like To Change Skin Now", ""):
            dialog.ok("Phantom", "The Window Will Change To Apperance Settings", "Please Choose From Skin Drop Down Menu", "And Select Your New Skin")
            xbmc.executebuiltin("XBMC.ActivateWindow(appearancesettings)")
 
        
        
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
        

def addDir(name,url,mode,iconimage,fanart,description,common):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&common="+urllib.quote_plus(common)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
        liz.setProperty("Fanart_Image", fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
        
        
 
        
#below tells plugin about the views                
def setView(content, viewType):
        # set content type so library shows more views and info
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
common=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        common=urllib.unquote_plus(params["common"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        Install(name,url,common)
        

       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
